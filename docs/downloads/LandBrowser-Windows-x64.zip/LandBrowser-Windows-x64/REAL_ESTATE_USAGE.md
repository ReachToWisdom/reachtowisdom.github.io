# Land Browser real estate workspace

## Search and projects

매매·전세·월세·단기임대와 주거용 매물 유형을 여러 개 선택할 수 있다. 서울·경기·인천의 시·도, 시·군·구, 읍·면·동을 순서대로 고른다. 동과 단지 선택기는 한 행에 나란히 있다. 매물 목록은 조건 편집 중에도 보이며, **네이버 매물 검색**을 누르면 검색 시작과 함께 조건 입력부가 접힌다. 한두 줄 요약을 눌러 다시 펼칠 수 있다. 초기화·검색 버튼은 펼침 상태에서 아래에 고정한다. 매물 목록 스크롤바는 숨겨져 있고 휠로 스크롤할 수 있다. 상세 조건에 스크롤이 필요하면 어두운 얇은 막대가 표시된다. 지역 자료 출처는 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)에 기록했다. 월세와 단기임대는 가격 조건을 보증금에 적용하며, 임대료 조건을 별도로 입력할 수 있다.

프로젝트에는 검색 조건, 보관 매물, 메모, 비교 구성을 저장한다. Kite 북마크바에는 저장된 비교 항목만 표시하며, 클릭하면 Land Browser의 고정 부동산 탭에서 해당 프로젝트와 비교 구성을 복원한다. 일반 북마크는 부동산 비교 북마크바에 표시하지 않는다. 개별 매물은 매물 카드나 상세 화면에서 보관하고, `지도 새 탭`은 현재 Land Browser 창 안에 새 탭을 연다.

데스크톱은 네이버 부동산 지도에 비교표 번호를 표시한다. 웹 앱 미리보기는 OpenStreetMap 바탕 지도에 같은 번호를 표시한다. 좌표가 없는 매물은 비교표에서 볼 수 있다.

검색 화면의 **상세 조건**은 기본으로 접혀 있다. 펼치면 층수, 방·욕실 개수, 여러 방향, 융자금, 입주·사용승인 연식, 단지 세대수 범위, 올수리·복층·급매·세안고 조건을 고를 수 있다. 프로젝트에 선택값을 저장하고 네이버 조회 조건에도 적용한다.

## Naver listing search

네이버 조회 모듈은 단지형과 동 단위 매물을 각각 조회한다. 데스크톱과 웹은 같은 검증과 동시 조회 제한을 적용한다. 유형, 기본값, 가격 단위, 조회 상한, API 요청 간격·재시도, 요구 대상 알림 주기는 [공통 기준 목록](src/integrations/land_catalog.json)에서 관리한다. 상한에 닿으면 화면에 **일부 조회**가 표시된다.

조건이 바뀌면 자동으로 조회한다. 같은 조건의 완료 결과가 24시간 안에 있으면 자동 조회를 건너뛴다. **네이버 매물 검색**으로 직접 갱신할 수 있다. 화면에는 현재 조건의 최신 결과와 직접 추가·가져온 매물이 표시된다. **보관 매물 함께 보기**로 이전 결과를 다시 볼 수 있다. 같은 조건의 완료 조회에서 빠진 매물은 미확인으로 표시한다. 공급자가 종료 상태를 명시한 경우에만 종료 상태를 표시한다.

단지와 평형이 하나로 확인되고 네이버에서 최근 매매 실거래를 제공하는 경우, 매물 가격 옆에 `(최근 매매 YYYY.MM · 금액)`을 표시한다. 일반 주택이나 평형을 특정할 수 없는 매물은 표시할 매매 기록이 없을 수 있다.

The endpoint is undocumented and is not an official Naver feed. The adapter does not bypass a login challenge, captcha, or rate limit. Automated access may be blocked under [Naver's policy](https://policy.naver.com/policy/disclaimer.html); use this route only with permission. A 401, 429 after retries, or changed response format is shown in the app. A future authorized feed can replace `src/integrations/naver_land.rs` while the UI and stored project format stay the same.

## 요구 대상 알림

요구 대상은 현재 필터의 지역, 단지, 거래·주거 유형, 가격, 임대료, 면적 및 상세 조건을 저장한다. 등록 직후 한 번 조회해 기존 매물 ID를 기준선으로 기록하고, 이후 새로 발견한 매물부터 알린다. 최소 검색 주기는 30분이며 선택지는 30분·1시간·6시간·매일이다. 각 주기는 직전 검색이 끝난 뒤 계산되므로 검색이 오래 걸리면 시작 시각은 설정 주기보다 늦을 수 있다. 앱이 실행 중일 때만 검사한다.

새 매물이 나오면 소리는 최초 알림에서 한 번 울린다. 확인하기 전까지 팝업과 트레이 알림은 5분마다 조용히 반복된다. 요구 대상 탭에서 **확인**을 누르면 반복을 멈춘다. 일시 중지·완료·수정·제거도 해당 탭에서 관리한다. 네이버 내부 비공식 경로에 요청하므로 짧은 주기로 낮추면 요청량과 차단 가능성이 커진다.

## Manual listing entry

Use **+ 직접 추가** to save a personal listing in the current project. It is stored locally with the project's other saved data; the app does not export or import listing JSON. Prices are in 만원 and areas in ㎡. Only HTTPS source URLs are accepted for opening in a new tab.

## Stored data

공유 프로젝트는 `%LOCALAPPDATA%\LandBrowser\RealEstate\shared-projects.json`에 저장한다. 저장 버전이 바뀐 경우 이전 버전으로 덮어쓰지 않는다. 저장 충돌이나 오류가 나면 화면에서 **미저장 변경 다운로드**를 사용할 수 있다. 브라우저는 미저장 변경을 창별로 보관한다.
