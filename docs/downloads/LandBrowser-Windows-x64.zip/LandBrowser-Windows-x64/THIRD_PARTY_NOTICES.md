# Third-party notices

## naver-land-mcp

`src/integrations/naver_land.rs` implements an adapter following the public endpoint flow and field conventions documented by [Seonh0/naver-land-mcp](https://github.com/Seonh0/naver-land-mcp). The repository is MIT licensed. Its license text is included at [resources/naver-land-mcp-LICENSE.txt](resources/naver-land-mcp-LICENSE.txt).

## Korean legal-dong address data

`src/ui/regions.json` contains the Seoul, Gyeonggi, and Incheon address hierarchy derived from [`swuhalee/korea-regions-with-coords`](https://github.com/swuhalee/korea-regions-with-coords), pinned to commit `426b795e8f4546eb41a9a46fd35098e9cc515e39`. That repository identifies the Ministry of the Interior and Safety code.go.kr legal-dong dataset as its source, with a February 2026 data date and Public Nuri Type 1 attribution for the legal-dong data. Only province, district, and eup/myeon/dong names are included; coordinates and ri-level data are omitted.

## Microsoft Edge WebView2 Runtime bootstrapper

The Windows installer includes Microsoft's Evergreen Bootstrapper, downloaded from the [official Microsoft distribution link](https://go.microsoft.com/fwlink/p/?LinkId=2124703) and retained with its Microsoft Authenticode signature. It installs the WebView2 Runtime only when the runtime is not already present. The runtime is distributed and licensed by Microsoft; see Microsoft's [WebView2 distribution documentation](https://learn.microsoft.com/microsoft-edge/webview2/concepts/distribution).
