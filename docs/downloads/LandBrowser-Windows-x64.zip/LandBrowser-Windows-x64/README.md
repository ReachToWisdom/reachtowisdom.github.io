# Land Browser Windows 배포본

Windows x64용 설치 프로그램과 포터블 ZIP을 제공합니다.

## 설치 프로그램

`LandBrowser-Setup.exe`는 현재 Windows 사용자에게 `%LOCALAPPDATA%\Programs\Land Browser`로 설치합니다. 시작 메뉴 바로가기를 만들고 설치 과정에서 바탕화면 바로가기를 선택할 수 있습니다. Microsoft Edge WebView2 Runtime이 없으면 공식 Microsoft Evergreen Bootstrapper를 실행해 준비합니다. 설치 후 시작 메뉴에서 **Land Browser**를 실행하세요.

작업 표시줄에 고정하려면 시작 메뉴에서 Land Browser를 찾아 마우스 오른쪽 버튼을 누르고 **작업 표시줄에 고정**을 선택합니다. Windows는 이 작업을 사용자 동작으로 처리합니다.

## 포터블 ZIP

1. ZIP을 원하는 폴더에 압축 해제합니다.
2. `land-browser.exe`를 실행합니다.
3. WebView2 Runtime이 설치되지 않은 PC에서는 Microsoft의 [WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/)을 먼저 설치하세요.

## 저장 위치

프로젝트·매물 상태는 `%LOCALAPPDATA%\LandBrowser\RealEstate\shared-projects.json`, 브라우저 프로필은 `%LOCALAPPDATA%\LandBrowser\UserData_Normal`에 저장됩니다. 앱 업데이트나 ZIP 교체 후에도 이 사용자 데이터는 유지됩니다. 종료를 요청하면 활성 프로젝트와 브라우저 세션을 저장한 뒤 앱이 닫힙니다.

매물 요구 대상은 앱이 실행 중일 때만 주기적으로 조회합니다. 새 매물 발견 시 소리는 한 번만 울리고, 팝업과 무음 트레이 알림은 사용자가 확인할 때까지 반복됩니다.

## 데이터 경로

현재 검색 어댑터는 네이버 부동산의 공개 문서화 API가 아닌 내부 조회 흐름을 사용합니다. 로그인·캡차·접근 제한을 우회하지 않습니다. 자동 수집은 네이버가 허용한 접근 경로나 사전 허락을 받은 경우에만 사용해야 합니다. 네이버 응답 형식 변경이나 접근 제한으로 조회가 중단될 수 있습니다. 세부 출처는 `THIRD_PARTY_NOTICES.md`, 사용법과 한계는 `REAL_ESTATE_USAGE.md`를 확인하세요.

